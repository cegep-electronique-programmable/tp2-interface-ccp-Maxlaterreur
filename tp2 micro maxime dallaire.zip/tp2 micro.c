/*
 * Maxime Dallaire
 * TP2
 * Microcotrôleurs et interfaces
 * Partie A
*/
#include "mcc_generated_files/mcc.h"
#include <stdio.h>

uint16_t commande;

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    PWM2_LoadDutyValue(30000); // Position neutre (1.5ms)

    printf("\n\rLocked(L) or Unlocked(U)?\n\r");

    while(1)
    {
        if (EUSART1_is_rx_ready())
        {
            commande = EUSART1_Read();

            if (commande == 'L')
            {
                PWM2_LoadDutyValue(40000); // Position barrée (2ms)
                printf("\n\rLocked Position!\n\r");
            }
            else if (commande == 'U')
            {
                PWM2_LoadDutyValue(20000); // Position débarrée (1ms)
                printf("\n\rUnlocked Position!\n\r");
            }
            else
            {
                printf("\n\rS.V.P. Choisir entre 'L' (Lock) et 'U' (Unlock)!\n\r");
            }
        }
    }
}
